"""Rewrite engine. Mechanical AI-pattern removal first, then style passes
driven by the user's profile so the output drifts toward their own voice."""
import random
import re

from . import patterns as P
from .detect import _title_case
from .style import DEFAULT_PROFILE
from .textutil import (is_prose_paragraph, match_case, recapitalize, sentences,
                       split_fences, words)

_SUBJECT_STARTS = {"the", "it", "this", "that", "he", "she", "they", "we", "there",
                   "these", "those", "a", "an", "its", "their", "some", "most", "many"}


_PUA = "\ue000-\uf8ff"
_LEAKS = [
    # ChatGPT citation and reference markup that survived a copy-paste
    re.compile(rf"[{_PUA}]*(?:cite|i|navlist)?(?:turn\d+(?:search|news|file|image|view)\d+)+[{_PUA}]*"),
    re.compile(r":?contentReference\[oaicite:\d+\]\{index=\d+\}"),
    re.compile(r"\boai_citation[:\w.-]*"),
    re.compile(r"<\|endoftext\|>"),
    re.compile(r"[ \t]*↩\ufe0e?\d*(?:[ \t]*↩\d*)*"),
]
_UTM_MID = re.compile(r"\?utm_source=(?:chatgpt\.com|openai)&")
_UTM = re.compile(r"[?&]utm_source=(?:chatgpt\.com|openai)(?![\w-]|\.\w)")
_HEDGE = re.compile(r"\b(could|might|may|can) (?:potentially|possibly|conceivably|arguably)\b", re.I)
_EMOJI = "\U0001F300-\U0001FAFF\u2600-\u27BF\u2B50\u2B55"
_EMOJI_LEAD = re.compile(rf"^([ \t]*(?:[-*+]|\d+[.)])?[ \t]*)[{_EMOJI}]\ufe0f?[ \t]+", re.M)


def _leaks(t):
    t = _UTM_MID.sub("?", t)
    t = _UTM.sub("", t)
    for rx in _LEAKS:
        t = rx.sub("", t)
    return t


def _hedges(t):
    return _HEDGE.sub(lambda m: m.group(1), t)


def _phrases(t, own):
    for pat, rep in P.PHRASES + P.TELL_PHRASES:
        t = re.sub(r"\b" + pat if pat[0] not in "(\\" or pat.startswith("(?") else pat,
                   lambda m, r=rep: m.group(0) if m.group(0).lower().strip(" ,") in own else match_case(m.group(0), r),
                   t, flags=re.I)
    return t


_AUX_BEFORE = {"will", "would", "can", "could", "should", "may", "might", "must", "shall",
               "to", "not", "also", "still", "then", "only", "just", "always", "never", "often"}
_AS_PLURAL_SUBJ = {"they", "we", "you", "i", "these", "those", "which", "who"}
_SERVE_AS = re.compile(r"\b(serves|serve|stands|stand|acts|act)\s+as\s+(?=(?:a|an|the|one|both|my|our|your|his|her|its|their)\b)", re.I)


def _serve_as(t, own):
    """"serves as a" -> "is a". Leaves "acts as if", "stands as high as", "serve as counsel"."""
    def sub(m):
        verb = m.group(1).lower()
        if m.group(0).lower().strip() in own:
            return m.group(0)
        prev = re.findall(r"[A-Za-z']+", t[max(0, m.start() - 20):m.start()])
        before = prev[-1].lower() if prev else ""
        if verb.endswith("s"):
            rep = "is "
        elif before in _AUX_BEFORE:
            rep = "be "
        elif not before or before in {"and", "or", "but"} and not prev[:-1]:
            rep = "be "                      # imperative: "Stand as a witness."
        else:
            rep = "are "
        return match_case(m.group(0), rep)
    return _SERVE_AS.sub(sub, t)


def _article(t):
    """Fix "a" / "an" in front of a word the vocab pass swapped ("a crucial" -> "an important")."""
    def sub(m):
        art, word = m.group(1), m.group(2)
        want = "an" if word[0].lower() in "aeiou" else "a"
        return match_case(art, want) + " " + word
    return re.sub(r"\b([Aa]n?) (" + "|".join(map(re.escape, _SWAPPED)) + r")\b", sub, t)


_SWAPPED = sorted({v.split()[0] for v in P.WORDS.values()} | {"many", "to", "for", "smoothly", "because"},
                  key=len, reverse=True)


def _vocab(t, own):
    def landscape(m):
        return match_case(m.group(1), m.group(1)) + (" scene" if m.group(1).lower() in P.LANDSCAPE_CTX else " landscape")
    t = re.sub(P.LANDSCAPE, landscape, t, flags=re.I)
    pat = r"\b(" + "|".join(sorted(map(re.escape, P.WORDS), key=len, reverse=True)) + r")\b"
    return re.sub(pat, lambda m: m.group(1) if m.group(1).lower() in own
                  else match_case(m.group(1), P.WORDS[m.group(1).lower()]), t, flags=re.I)


def _structure(t):
    # "It's not just X, it's Y." -> "It's Y."
    def parallel(m):
        start = m.start()
        head = m.string[:start].rstrip(" \t")
        sentence_start = not head or head[-1] in ".!?\n\"“”‘("
        return ("It is " if sentence_start else "it is ") + ("about " if m.group("ab") else "")
    t = re.sub(r"\b(?:it|this|that)(?:(?:'|’)s| is)? ?(?:not|n(?:'|’)t) (?:just |only |merely |simply )?(?:about )?(?!that\b)"
               r"[^.;!?]{2,80}?[,;—-]+\s*(?:but |it(?:'|’)s |it is |this is )(?:also )?(?P<ab>about )?",
               parallel, t, flags=re.I)
    # "X is not merely a trend; it is a shift." -> "X is a shift."
    t = re.sub(r"\b(is|are|was|were)(?: not|n(?:'|’)t) (?:just|only|merely|simply) (?:an? |the )?(?!that\b)[^.;!?]{2,60}?[;,—-]+\s*"
               r"(?:it(?:'|’)s |it is |this is |that is )(?=(?:an?|the|\w+) )", r"\1 ", t, flags=re.I)
    # trailing "-ing" riders: ", highlighting how ..." -> "."
    tails = "|".join(map(re.escape, P.TAIL_VERBS))
    t = re.sub(rf"(?:,|\s—|\s--)\s+(?:{tails})\b(?:[^.!?\n]|\.(?=\d|\w\.))*([.!?])", r"\1", t, flags=re.I)
    # vague "ensuring" riders ("ensuring long-term wellbeing"); concrete ones ("ensuring the trial finished") stay
    t = re.sub(r"(?:,|\s—|\s--)\s+ensuring (?:long-term|lasting|sustained|continued|ongoing|a (?:seamless|smooth|bright|brighter|better)|"
               r"that (?:everyone|all)\b)(?:[^.!?\n]|\.(?=\d|\w\.))*([.!?])", r"\1", t, flags=re.I)
    return t


def _typography(t, profile, strip_bold=True):
    if profile["curly_quote_rate"] < 0.05:
        t = t.translate({0x201C: '"', 0x201D: '"', 0x2018: "'", 0x2019: "'"})
    if strip_bold:
        t = re.sub(r"\*\*([^*\n]+)\*\*", r"\1", t)
    t = re.sub(r"^(#+ )[^\w\n]*", r"\1", t, flags=re.M)       # emoji/arrows in headings
    t = _EMOJI_LEAD.sub(r"\1", t)                              # emoji leading a line or bullet
    return t


_HEAD = re.compile(r"^(#{1,6} +)(.+)$", re.M)


def _proper_nouns(body):
    """Capitalised words that appear mid-sentence in the body: names, not Title Case."""
    mid = set(re.findall(r"(?<=[a-z0-9,;:)\"”’] )([A-Z][A-Za-z’']*)", body))
    # a capitalised sentence-opener is a name too if its lowercase form never appears
    low = set(re.findall(r"\b[a-z][a-z’']*\b", body))
    return mid | {w for w in re.findall(r"\b[A-Z][a-z’']+\b", body) if w.lower() not in low}


def _headings(t, ctx):
    """Title Case headings -> sentence case, keeping names and acronyms the body proves are names."""
    if not _HEAD.search(t):
        return t
    body = _HEAD.sub("", ctx)
    proper = _proper_nouns(body)

    lowwords = set(re.findall(r"\b[a-z][a-z’']*\b", body))

    def fix(m):
        h = m.group(2)
        two = re.fullmatch(r"([A-Z][a-z’']+) ([A-Z][a-z’']+)", h)
        if two and two.group(2) not in proper and two.group(2).lower() in lowwords:
            return m.group(1) + two.group(1) + " " + two.group(2).lower()    # "Key Benefits" -> "Key benefits"
        if not _title_case(h):
            return m.group(0)
        first = [True]

        def word(w):
            lead = first[0]
            first[0] = False
            core = w.group(0)
            if lead or core.isupper() or core in proper or any(c.isupper() for c in core[1:]):
                return core
            return core.lower()
        return m.group(1) + re.sub(r"[A-Za-z][A-Za-z’'-]*", word, h)
    return _HEAD.sub(fix, t)


def _dashes(t, profile, rng):
    t = re.sub(r"(?<=\d)\s*—\s*(?=\d)", "–", t)               # 2020—2024 is a range, not an aside
    n_words = max(len(words(t)), 1)
    budget = round(profile["em_dashes_per_100w"] * n_words / 100)
    ell = profile["ellipses_per_100w"] > 0.15
    dashes = list(re.finditer(r"\s*—\s*", t))
    token, ell_tok = profile["dash_token"], profile["ellipsis_token"]
    keep = set(rng.sample(range(len(dashes)), min(budget, len(dashes)))) if dashes else set()
    out, last = [], 0
    for i, m in enumerate(dashes):
        out.append(t[last:m.start()])
        if i in keep:
            out.append(token)
        elif ell and rng.random() < min(profile["ellipses_per_100w"] / 0.5, 0.6):
            out.append(ell_tok + " ")
        else:
            out.append(", ")
        last = m.end()
    out.append(t[last:])
    return "".join(out)


def _contractions(t, profile, rng):
    p = min(profile["contractions_per_100w"] / 2.0, 1.0)      # ~2/100w => always
    curly = profile["curly_quote_rate"] > 0.5
    for pat, rep in P.CONTRACTIONS:
        rep = rep.replace("'", "’") if curly else rep
        if "n't" not in rep:                 # "here we are." must not become "here we're."
            pat += r"(?=\s+[A-Za-z])"
        t = re.sub(pat, lambda m, r=rep: match_case(m.group(0), r) if rng.random() < p else m.group(0),
                   t, flags=0 if pat.startswith(r"\bI") else re.I)
    return t


def _rhythm(par, profile, rng):
    """Push sentence lengths toward the profile's spread: split run-ons,
    glue neighbouring fragments, now and then start with And/But/So."""
    sents = sentences(par)
    if len(sents) < 2:
        return par
    target_mean, target_sd = profile["mean_sentence_len"], profile["sentence_len_stdev"]
    out, i = [], 0
    while i < len(sents):
        s = sents[i]
        n = len(words(s))
        if n > max(target_mean + 1.6 * target_sd, 30):
            m = re.search(r",\s+(but|and|so|yet)\s+", s[len(s)//3: 2*len(s)//3 + 20])
            if m:
                cut = len(s)//3 + m.start()
                head, conj, rest = s[:cut], m.group(1), s[len(s)//3 + m.end():]
                if rng.random() < max(profile["conjunction_start_rate"] * 6, 0.4) and words(rest):
                    out.append(head + ".")
                    out.append(conj.capitalize() + " " + rest)
                    i += 1
                    continue
        if (i + 1 < len(sents) and n < 8 and len(words(sents[i + 1])) < 9
                and target_sd < 6 and s[-1] == "." and rng.random() < 0.5):
            nxt = sents[i + 1]
            first = words(nxt)[0].lower() if words(nxt) else ""
            if first in _SUBJECT_STARTS:
                out.append(s[:-1] + ", and " + nxt[0].lower() + nxt[1:])
                i += 2
                continue
        out.append(s)
        i += 1
    return " ".join(out)


def _casual(t, profile):
    if profile["lowercase_i_rate"] > 0.6:
        t = re.sub(r"\bI\b", "i", t)
        t = re.sub(r"\bI(?=['’])", "i", t)
    return t


def humanize(text, profile=None, seed=None, strip_bold=True, rhythm=True, register="auto"):
    from .style import pick_register
    profile = {**DEFAULT_PROFILE, **(profile or {})}
    if register == "auto":
        profile = pick_register(profile, text)
    elif register in profile.get("registers", {}):
        profile = {**profile, **profile["registers"][register], "register": register}
    own = set(profile["own_phrases"])
    rng = random.Random(seed)
    result = []
    for is_code, chunk in split_fences(text):
        if is_code:
            result.append(chunk)
            continue
        t = _leaks(chunk)
        t = _typography(t, profile, strip_bold)
        t = _headings(t, text)
        t = _phrases(t, own)
        t = _serve_as(t, own)
        t = _hedges(t)
        t = _structure(t)
        t = _vocab(t, own)
        t = _article(t)
        t = _dashes(t, profile, rng)
        t = _contractions(t, profile, rng)
        pars = re.split(r"(\n\s*\n)", t)
        pars = [(_rhythm(p, profile, rng) if rhythm and is_prose_paragraph(p) else p) for p in pars]
        t = "".join(pars)
        t = re.sub(r"[ \t]{2,}", " ", t)
        t = re.sub(r" +([,.;:!?])", r"\1", t)
        t = re.sub(r",\s*,", ",", t)
        t = recapitalize(t)
        if profile["lowercase_start_rate"] > 0.6:
            t = re.sub(r"(^|(?<=[.!?]) )([A-Z])(?=[a-z])", lambda m: m.group(1) + m.group(2).lower(), t, flags=re.M)
        t = _casual(t, profile)
        if profile["curly_quote_rate"] > 0.5:
            t = re.sub(r"(?<=\w)'(?=\w)", "’", t)
        result.append(t)
    return "".join(result).strip() + "\n"
