import argparse
import json
import sys
from pathlib import Path

from .detect import score
from .rewrite import humanize
from .style import analyze, build_profile, load_profile, pick_register


def main(argv=None):
    ap = argparse.ArgumentParser(prog="humanizer", description="Strip AI tells and match your own writing style.")
    ap.add_argument("file", nargs="?", help="input file (default: stdin)")
    ap.add_argument("-o", "--out", help="write result here (default: stdout)")
    ap.add_argument("--samples", default=str(Path(__file__).resolve().parent.parent / "samples"),
                    help="folder of your own .txt/.md writing (default: samples/ next to the package)")
    ap.add_argument("--profile", help="saved profile JSON (overrides --samples)")
    ap.add_argument("--learn", action="store_true", help="analyze samples, save profile.json, and exit")
    ap.add_argument("--score", action="store_true", help="only print the AI-tell report")
    ap.add_argument("--register", default="auto", help="auto (closest to the draft), or a samples sub-folder name, e.g. academic")
    ap.add_argument("--seed", type=int, help="make output repeatable")
    ap.add_argument("--keep-bold", action="store_true")
    ap.add_argument("--no-rhythm", action="store_true", help="skip sentence splitting/merging")
    a = ap.parse_args(argv)

    if a.learn:
        prof = build_profile(a.samples)
        Path("profile.json").write_text(json.dumps(prof, indent=2))
        print(json.dumps(prof, indent=2))
        return 0

    text = Path(a.file).read_text(encoding="utf-8") if a.file else sys.stdin.read()
    if a.score:
        print(json.dumps(score(text), indent=2))
        return 0

    prof = load_profile(a.profile, a.samples)
    if not prof["samples"]:
        sys.stderr.write("warning: no style profile found, using neutral defaults (see --samples / --profile)\n")
    out = humanize(text, prof, seed=a.seed, register=a.register, strip_bold=not a.keep_bold, rhythm=not a.no_rhythm)
    reg = pick_register(prof, text).get("register", "none") if a.register == "auto" else a.register
    before, after = score(text)["score"], score(out)["score"]
    sys.stderr.write(f"ai-tell score: {before} -> {after}  (style: {reg}; samples used: {prof['samples']})\n")
    if a.out:
        Path(a.out).write_text(out, encoding="utf-8")
    else:
        sys.stdout.write(out)
    return 0
